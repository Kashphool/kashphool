/*
  DESIGN: Sacred Geometry Modernism
  Home page — assembles all sections with decorative dividers
*/

import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import EventsSection from "@/components/EventsSection";
import GallerySection from "@/components/GallerySection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import SectionDivider from "@/components/SectionDivider";

export default function Home() {
  return (
    <div className="min-h-screen bg-charcoal text-ivory">
      <Navbar />
      <HeroSection />
      <SectionDivider withAccent />
      <AboutSection />
      <SectionDivider />
      <EventsSection />
      <SectionDivider withAccent />
      <GallerySection />
      <SectionDivider />
      <ContactSection />
      <Footer />
    </div>
  );
}
